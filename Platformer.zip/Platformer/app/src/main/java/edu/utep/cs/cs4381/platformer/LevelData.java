package edu.utep.cs.cs4381.platformer;

import java.util.List;

public class LevelData {

    protected List<String> tiles;
}