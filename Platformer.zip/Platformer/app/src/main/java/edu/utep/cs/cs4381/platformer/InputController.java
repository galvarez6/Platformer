package edu.utep.cs.cs4381.platformer;

class InputController {

    public InputController(int screenWidth, int screenHeight) {
    }
}